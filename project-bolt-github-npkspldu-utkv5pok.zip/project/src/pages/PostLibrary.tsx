import PostLibraryContent from "@/components/PostLibraryContent"

export default function PostLibrary() {
  return <PostLibraryContent />
}