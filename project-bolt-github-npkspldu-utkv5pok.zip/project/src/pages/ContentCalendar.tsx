import ContentCalendarView from "@/components/ContentCalendarView"

export default function ContentCalendar() {
  return <ContentCalendarView />
}